<?php

return array(
    'host' => 'localhost',
    'dbname' => 'phonebook',
    'user' => 'root',
    'password' => '9919',
);
